document.getElementById("btn").onclick = () => {
  document.getElementById("output").innerText